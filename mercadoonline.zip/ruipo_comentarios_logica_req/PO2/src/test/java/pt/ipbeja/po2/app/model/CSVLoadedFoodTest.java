/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 * Totalmente feita por AI
 */

package pt.ipbeja.po2.app.model;

import org.junit.jupiter.api.Test;
import pt.ipbeja.app.model.LoadedFoods;
import pt.ipbeja.app.model.TransformsLinesToObjects;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Lógica: testa a leitura do ficheiro CSV principal.
 * Requisitos: Req. 2, Req. 3.
 */
public class CSVLoadedFoodTest {

    /**
     * Lógica: confirma que o CSV principal carrega 11 alimentos e não gera linhas ignoradas.
     * Requisitos: Req. 2, Req. 3.
     */
    @Test
    public void testLoadFoodsFromCsv() {
        TransformsLinesToObjects factory = new TransformsLinesToObjects();

        LoadedFoods result = factory.FoodsFromCSV(
                "src/main/resources/foods.csv"
        );

        System.out.println(result.getIgnoredLinesText());
        assertEquals(11, result.getFoods().size());
        assertFalse(result.hasIgnoredLines());
    }
}