/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.po2.app.model;

import org.junit.jupiter.api.Test;
import pt.ipbeja.app.model.*;

import static org.junit.jupiter.api.Assertions.*;


/**
 * Lógica: testa os cálculos principais do modelo e dos alimentos.
 * Requisitos: Req. 2.
 */
public class BasketModelTest {


    /**
     * Lógica: confirma que um alimento embalado devolve o preço base.
     * Requisitos: Req. 2.
     */
    @Test
    public void testPackagedPrice() {
        PackagedFood esparguete = new PackagedFood(
                "Esparguete",
                FoodGroup.YELLOW,
                1.20,
                350,
                "Plastic"
        );

        assertEquals(1.20, esparguete.getPrice(), 0.001);
    }

    /**
     * Lógica: confirma que um alimento a granel calcula o preço proporcional ao peso.
     * Requisitos: Req. 2.
     */
    @Test
    public void testBulkPriceCalculation() {
        BulkFood batatas = new BulkFood(
                "Batatas",
                FoodGroup.GREEN,
                2.00,
                520,
                500
        );

        assertEquals(1.00, batatas.getPrice(), 0.001);
    }

    /**
     * Lógica: confirma que o BasketModel soma alimentos diferentes usando polimorfismo.
     * Requisitos: Req. 2.
     */
    @Test
    public void testTotalBasketCalculation() {
        BasketModel model = new BasketModel();

        FoodItem rice = new PackagedFood(
                "Arroz",
                FoodGroup.YELLOW,
                1.20,
                350,
                "Plastic"
        );

        FoodItem apples = new BulkFood(
                "Maçãs",
                FoodGroup.GREEN,
                2.00,
                520,
                500
        );

        model.addItem(rice);
        model.addItem(apples);

        assertEquals(2.20, model.getTotalPrice(), 0.001);
    }

    /**
     * Lógica: confirma que a meta ODS 3 falha abaixo de 400g GREEN e é cumprida acima desse valor.
     * Requisitos: Req. 2.
     */
    @Test
    public void testSDGGoalCondition() {
        BasketModel successfulModel = new BasketModel();

        FoodItem apples = new BulkFood(
                "Maçã vermelha",
                FoodGroup.GREEN,
                2.00,
                520,
                500
        );

        successfulModel.addItem(apples);

        assertTrue(successfulModel.isOds3Achieved());

        BasketModel failedModel = new BasketModel();

        FoodItem carrots = new BulkFood(
                "Cenoura roxa",
                FoodGroup.GREEN,
                1.50,
                410,
                300
        );

        failedModel.addItem(carrots);

        assertFalse(failedModel.isOds3Achieved());
    }
}
