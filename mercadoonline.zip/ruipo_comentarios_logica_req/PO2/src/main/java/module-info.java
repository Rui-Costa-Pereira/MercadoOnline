/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

module pt.ipbeja {
    requires javafx.controls;
    exports pt.ipbeja.app.ui;
    exports pt.ipbeja.app.model;

}