/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.util.Optional;

/**
 * Lógica: define a interface de comunicação entre o modelo e a interface gráfica.
 * Requisitos: Req. 4, Req. 7, RPB 1.
 */
public interface View {

    /**
     * Lógica: contrato para a View atualizar a informação visual quando o modelo muda.
     * Requisitos: Req. 4, Req. 7, Req. 10, Req. 12.
     */
    void update();

    /**
     * Lógica: contrato para pedir ao utilizador o peso escolhido de um alimento a granel.
     * Requisitos: Req. 4.
     */
    Optional<Double> askSelectedWeight(String foodName);

    /**
     * Lógica: contrato para mostrar mensagens de erro ao utilizador.
     * Requisitos: Req. 3, Req. 4, Req. 10, Req. 12.
     */
    void showError(String message);

    /**
     * Lógica: contrato para mostrar as linhas do CSV ignoradas.
     * Requisitos: Req. 3, Req. 4.
     */
    void showIgnoredLines(String ignoredLinesText);


    /**
     * Lógica: contrato para atualizar o estado visual dos emblemas ODS.
     * Requisitos: Req. 7, RPB 1.
     */
    void updateOdsBadges(boolean ods2Achieved, boolean ods3Achieved, boolean ods12Achieved);
}