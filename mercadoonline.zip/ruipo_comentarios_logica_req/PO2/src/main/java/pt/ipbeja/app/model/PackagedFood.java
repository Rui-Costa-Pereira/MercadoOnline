/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;
import java.util.Optional;
/**
 * Lógica: representa alimentos embalados vendidos à unidade e com material de embalagem.
 * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, Req. 6, Req. 7, Req. 12, RPB 2.
 */
public class PackagedFood extends FoodItem {

    private final String packagingMaterial;

    /**
     * Lógica: cria um alimento embalado com os dados comuns e o material de embalagem.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, Req. 6, Req. 7, Req. 12.
     */
    public PackagedFood(String name, FoodGroup group, double basePrice,
                        double baseCalories, String packagingMaterial)
    {
        super(name, group, basePrice, baseCalories);
        this.packagingMaterial = packagingMaterial;
    }

    /**
     * Lógica: devolve o material da embalagem.
     * Requisitos: Req. 1, Req. 7.
     */
    public String getPackagingMaterial() {
        return this.packagingMaterial;
    }

    /**
     * Lógica: devolve o preço unitário fixo do alimento embalado.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5.
     */
    @Override
    public double getPrice() {
        return this.getBasePrice();
    }

    /**
     * Lógica: devolve as calorias base da unidade embalada.
     * Requisitos: Req. 1, Req. 2, Req. 4.
     */
    @Override
    public double getCalories() {
        return this.getBaseCalories();
    }

    /**
     * Lógica: adiciona diretamente o alimento embalado ao cabaz sem pedir peso.
     * Requisitos: Req. 4, RPB 2.
     */
    @Override
    public void addToBasket(BasketModel model, View view) {
        model.addItem(this);
    }

    /**
     * Lógica: devolve o texto usado no tile para identificar venda por unidade.
     * Requisitos: Req. 6.
     */
    @Override
    public String getSaleTypeText() {
        return "Embalado - €/un.";
    }

    /**
     * Lógica: formata a quantidade de um embalado no recibo como uma unidade.
     * Requisitos: Req. 5.
     */
    @Override
    public String getReceiptQuantityText() {
        return "1 unidade";
    }

    /**
     * Lógica: verifica se o material da embalagem é plástico para a regra ODS 12.
     * Requisitos: Req. 7.
     */
    @Override
    public boolean hasPlasticPackaging() {
        return this.packagingMaterial.equalsIgnoreCase("Plastico") ||
                this.packagingMaterial.equalsIgnoreCase("Plastic");
    }

    /**
     * Lógica: reconstrói um alimento embalado quando o recibo indica uma unidade.
     * Requisitos: Req. 12.
     */
    @Override
    public Optional<FoodItem> createFromReceiptQuantity(String quantityText) {
        Optional<FoodItem> foodItem = Optional.empty();

        if (quantityText.toLowerCase().contains("unidade")) {
            foodItem = Optional.of(this);
        }

        return foodItem;
    }

}
