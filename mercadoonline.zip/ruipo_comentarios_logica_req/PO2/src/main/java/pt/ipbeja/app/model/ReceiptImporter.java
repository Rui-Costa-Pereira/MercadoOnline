/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Lógica: importa itens a partir de um recibo previamente exportado.
 * Requisitos: Req. 12.
 */
public class ReceiptImporter {

    private static final String RECEIPT_SEPARATOR = "\\|";
    private static final int RECEIPT_NAME_INDEX = 0;
    private static final int RECEIPT_QUANTITY_INDEX = 1;
    private static final int MINIMUM_RECEIPT_FIELDS = 3;

    /**
     * Lógica: lê um recibo e devolve os itens reconstruídos a partir dos alimentos disponíveis.
     * Requisitos: Req. 12.
     */
    public List<FoodItem> importReceiptItems(String filePath, List<FoodItem> availableFoods)
            throws IOException {
        List<FoodItem> importedItems = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            this.readReceiptLines(reader, availableFoods, importedItems);
        }

        return importedItems;
    }

    /**
     * Lógica: percorre o ficheiro linha a linha e tenta importar cada linha.
     * Requisitos: Req. 12.
     */
    private void readReceiptLines(BufferedReader reader,
                                  List<FoodItem> availableFoods,
                                  List<FoodItem> importedItems) throws IOException {
        String line = reader.readLine();

        while (line != null) {
            this.importReceiptLine(line, availableFoods, importedItems);
            line = reader.readLine();
        }
    }

    /**
     * Lógica: tenta transformar uma linha do recibo num FoodItem e adiciona-o se for válido.
     * Requisitos: Req. 12.
     */
    private void importReceiptLine(String line,
                                   List<FoodItem> availableFoods,
                                   List<FoodItem> importedItems) {
        Optional<FoodItem> foodItem = this.createFoodItemFromReceiptLine(line, availableFoods);

        if (foodItem.isPresent()) {
            importedItems.add(foodItem.get());
        }
    }

    /**
     * Lógica: divide a linha pelo separador do recibo e ignora linhas que não sejam de itens.
     * Requisitos: Req. 12.
     */
    private Optional<FoodItem> createFoodItemFromReceiptLine(String line,
                                                             List<FoodItem> availableFoods) {
        Optional<FoodItem> foodItem = Optional.empty();

        String[] fields = line.split(RECEIPT_SEPARATOR);

        if (fields.length >= MINIMUM_RECEIPT_FIELDS) {
            foodItem = this.createFoodItemFromReceiptFields(fields, availableFoods);
        }

        return foodItem;
    }

    /**
     * Lógica: retira o nome e a quantidade da linha para reconstruir o item.
     * Requisitos: Req. 12.
     */
    private Optional<FoodItem> createFoodItemFromReceiptFields(String[] fields,
                                                               List<FoodItem> availableFoods) {
        String foodName = fields[RECEIPT_NAME_INDEX].trim();
        String quantityText = fields[RECEIPT_QUANTITY_INDEX].trim();

        return this.createFoodItemByNameAndQuantity(foodName, quantityText, availableFoods);
    }

    /**
     * Lógica: procura o alimento disponível pelo nome e delega na subclasse a criação pela quantidade.
     * Requisitos: Req. 12, RPB 2.
     */
    private Optional<FoodItem> createFoodItemByNameAndQuantity(String foodName,
                                                               String quantityText,
                                                               List<FoodItem> availableFoods) {
        Optional<FoodItem> foodItem = Optional.empty();

        for (FoodItem availableFood : availableFoods) {
            if (availableFood.getName().equalsIgnoreCase(foodName)) {
                foodItem = availableFood.createFromReceiptQuantity(quantityText);
            }
        }

        return foodItem;
    }
}