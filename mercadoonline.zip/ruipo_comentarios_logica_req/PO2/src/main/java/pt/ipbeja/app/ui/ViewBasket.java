/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.ui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import pt.ipbeja.app.model.BasketModel;
import pt.ipbeja.app.model.FoodItem;
import pt.ipbeja.app.model.LoadedFoods;
import pt.ipbeja.app.model.View;
import pt.ipbeja.app.model.FoodGroup;

import java.io.IOException;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import java.util.Comparator;


import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.FileChooser;
import javafx.util.Duration;

import java.io.File;

/**
 * Lógica: implementa a interface gráfica JavaFX e envia as ações do utilizador para o modelo.
 * Requisitos: Req. 3, Req. 4, Req. 5, Req. 6, Req. 7, Req. 8, Req. 10, Req. 12, RPB 1, RPB 2.
 */
public class ViewBasket extends Application implements View {

    private BasketModel model;

    private Label totalPriceLabel;
    private Label totalCaloriesLabel;
    private VBox boughtItemsBox;
    private Label ods2BadgeLabel;
    private Label ods3BadgeLabel;
    private Label ods12BadgeLabel;

    private static final String FILTER_ALL = "Mostrar Todos";
    private static final String FILTER_GREEN = "Só Fruta/Vegetais";
    private static final String FILTER_PROTEINS = "Só Proteínas";

    private static final String ORDER_NONE = "Sem ordenação";
    private static final String ORDER_PRICE_ASC = "Preço Menor a Maior";
    private static final String ORDER_CALORIES_DESC = "Mais calóricos primeiro";

    private GridPane foodGrid;
    private String currentFilter;
    private String currentOrder;

    /**
     * Lógica: inicializa o modelo, lê o CSV, constrói a janela e faz a primeira atualização visual.
     * Requisitos: Req. 3, Req. 4, Req. 7, Req. 8, Req. 10, Req. 12.
     */
    @Override
    public void start(Stage stage) {
        this.model = new BasketModel();
        this.model.setView(this);

        LoadedFoods loadedFoods = this.model.loadAvailableFoods("src/main/resources/foods.csv");
        this.showLoadWarnings(loadedFoods);

        BorderPane root = this.createRoot(stage);

        Scene scene = new Scene(root, 1000, 600);

        stage.setTitle("Mercado PO2");
        stage.setScene(scene);
        stage.show();

        this.update();
        this.updateOdsBadges(false, false, false);
    }

    /**
     * Lógica: organiza menu, filtros, grelha e dashboard na janela principal.
     * Requisitos: Req. 4, Req. 8, Req. 12.
     */
    private BorderPane createRoot(Stage stage) {
        BorderPane root = new BorderPane();

        MenuBar menuBar = this.createMenuBar(stage);

        this.currentFilter = FILTER_ALL;
        this.currentOrder = ORDER_NONE;

        HBox filterBar = this.createFilterBar();

        this.foodGrid = new GridPane();
        this.foodGrid.setHgap(10);
        this.foodGrid.setVgap(10);
        this.foodGrid.setStyle("-fx-padding: 20;");

        VBox centerArea = new VBox(filterBar, this.foodGrid);
        centerArea.setSpacing(10);

        VBox dashboard = this.createDashboard();

        root.setTop(menuBar);
        root.setCenter(centerArea);
        root.setRight(dashboard);

        this.refreshFoodGrid();

        return root;
    }

    /**
     * Lógica: cria o tile visual de um alimento e envia o clique para o modelo.
     * Requisitos: Req. 4, Req. 6, RPB 1.
     */
    private VBox createFoodTile(FoodItem food) {
        Label nameLabel = new Label(food.getName());
        Label priceLabel = new Label(String.format("Preço base: %.2f €", food.getBasePrice()));
        Label typeLabel = new Label(food.getSaleTypeText());

        VBox tile = new VBox(nameLabel, priceLabel, typeLabel);

        tile.setSpacing(5);
        tile.setPrefSize(160, 100);
        tile.setStyle(this.createTileStyle(food));
        tile.setOnMouseClicked(event -> this.model.selectFood(food));

        return tile;
    }

    /**
     * Lógica: monta o estilo CSS do tile com base na cor do grupo alimentar.
     * Requisitos: Req. 4.
     */
    private String createTileStyle(FoodItem food) {
        return "-fx-background-color: " + food.getGroup().getColorName() + ";" +
                "-fx-padding: 10;" +
                "-fx-border-color: black;" +
                "-fx-border-width: 1;";
    }

    /**
     * Lógica: cria o painel lateral com totais, itens comprados, emblemas ODS e finalizar compra.
     * Requisitos: Req. 4, Req. 5, Req. 7.
     */
    private VBox createDashboard() {
        Label titleLabel = new Label("Cabaz");
        this.totalPriceLabel = new Label();
        this.totalCaloriesLabel = new Label();

        Label itemsTitleLabel = new Label("Itens comprados:");
        this.boughtItemsBox = new VBox();
        this.boughtItemsBox.setSpacing(5);

        Label odsTitleLabel = new Label("Emblemas ODS:");
        VBox odsBadgesBox = this.createOdsBadgesBox();

        Button finishButton = new Button("Finalizar Compra");
        finishButton.setOnAction(event -> this.finishPurchase());

        VBox dashboard = new VBox(
                titleLabel,
                this.totalPriceLabel,
                this.totalCaloriesLabel,
                itemsTitleLabel,
                this.boughtItemsBox,
                odsTitleLabel,
                odsBadgesBox,
                finishButton
        );


        dashboard.setSpacing(10);
        dashboard.setPrefWidth(260);
        dashboard.setStyle("-fx-padding: 20; -fx-background-color: #eeeeee;");

        return dashboard;
    }

    /**
     * Lógica: atualiza a informação visual quando o modelo notifica alterações.
     * Requisitos: Req. 4, Req. 7, Req. 10, Req. 12.
     */
    @Override
    public void update() {
        this.updateTotals();
        this.updateBoughtItems();
    }

    /**
     * Lógica: mostra na View o custo total e as calorias totais calculadas pelo modelo.
     * Requisitos: Req. 4.
     */
    private void updateTotals() {
        this.totalPriceLabel.setText(
                String.format("Custo Total: %.2f €", this.model.getTotalPrice())
        );

        this.totalCaloriesLabel.setText(
                String.format("Calorias Totais: %.2f kcal", this.model.getTotalCalories())
        );
    }

    /**
     * Lógica: reconstrói a lista visual dos itens comprados a partir da cópia fornecida pelo modelo.
     * Requisitos: Req. 4.
     */
    private void updateBoughtItems() {
        this.boughtItemsBox.getChildren().clear();

        for (FoodItem item : this.model.getItems()) {
            Label itemLabel = new Label(item.getName());
            this.boughtItemsBox.getChildren().add(itemLabel);
        }
    }

    /**
     * Lógica: pede ao utilizador as gramas de um alimento a granel.
     * Requisitos: Req. 4.
     */
    @Override
    public Optional<Double> askSelectedWeight(String foodName) {
        TextInputDialog dialog = new TextInputDialog();

        dialog.setTitle("Peso");
        dialog.setHeaderText("Adicionar " + foodName);
        dialog.setContentText("Quantas gramas deseja adicionar?");

        Optional<String> result = dialog.showAndWait();

        return this.parseWeight(result);
    }

    /**
     * Lógica: transforma o resultado opcional do diálogo num peso opcional.
     * Requisitos: Req. 4.
     */
    private Optional<Double> parseWeight(Optional<String> result) {
        Optional<Double> selectedWeight = Optional.empty();

        if (result.isPresent()) {
            selectedWeight = this.tryParseWeight(result.get());
        }

        return selectedWeight;
    }

    /**
     * Lógica: converte texto para double e mostra erro se o valor não for numérico.
     * Requisitos: Req. 4.
     */
    private Optional<Double> tryParseWeight(String text) {
        Optional<Double> selectedWeight = Optional.empty();

        try {
            selectedWeight = Optional.of(Double.parseDouble(text));
        } catch (NumberFormatException exception) {
            this.showError("Peso inválido.");
        }

        return selectedWeight;
    }

    /**
     * Lógica: mostra uma mensagem de erro ao utilizador.
     * Requisitos: Req. 3, Req. 4, Req. 10, Req. 12.
     */
    @Override
    public void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);

        alert.setTitle("Erro");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Lógica: mostra num aviso as linhas do CSV que foram ignoradas.
     * Requisitos: Req. 3, Req. 4.
     */
    @Override
    public void showIgnoredLines(String ignoredLinesText) {
        Alert alert = new Alert(Alert.AlertType.WARNING);

        alert.setTitle("Linhas ignoradas");
        alert.setHeaderText("Algumas linhas do CSV foram ignoradas");
        alert.setContentText(ignoredLinesText);
        alert.showAndWait();
    }

    /**
     * Lógica: verifica se houve linhas ignoradas no carregamento do CSV e mostra aviso.
     * Requisitos: Req. 3, Req. 4.
     */
    private void showLoadWarnings(LoadedFoods loadedFoods) {
        if (loadedFoods.hasIgnoredLines()) {
            this.showIgnoredLines(loadedFoods.getIgnoredLinesText());
        }
    }

    /**
     * Lógica: mostra uma mensagem informativa após uma operação bem-sucedida.
     * Requisitos: Req. 5.
     */
    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);

        alert.setTitle("Compra finalizada");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Lógica: pede ao modelo para exportar o recibo e informa o utilizador do ficheiro criado.
     * Requisitos: Req. 5.
     */
    private void finishPurchase() {
        try {
            String fileName = this.model.exportReceipt();
            this.showInfo("Recibo criado: " + fileName);
        } catch (IOException exception) {
            this.showError("Não foi possível criar o recibo.");
        }
    }

    /**
     * Lógica: cria a caixa visual com os três emblemas ODS.
     * Requisitos: Req. 7.
     */
    private VBox createOdsBadgesBox() {
        this.ods2BadgeLabel = this.createOdsBadge("ODS 2 - Fome Zero");
        this.ods3BadgeLabel = this.createOdsBadge("ODS 3 - Saúde");
        this.ods12BadgeLabel = this.createOdsBadge("ODS 12 - Sustentabilidade");

        VBox badgesBox = new VBox(
                this.ods2BadgeLabel,
                this.ods3BadgeLabel,
                this.ods12BadgeLabel
        );

        badgesBox.setSpacing(6);

        return badgesBox;
    }

    /**
     * Lógica: cria um emblema ODS inicialmente inativo.
     * Requisitos: Req. 7.
     */
    private Label createOdsBadge(String text) {
        Label badge = new Label(text);

        badge.setPrefWidth(210);
        badge.setStyle(this.createInactiveBadgeStyle());

        return badge;
    }

    /**
     * Lógica: devolve o estilo cinzento usado por emblemas ainda não cumpridos.
     * Requisitos: Req. 7.
     */
    private String createInactiveBadgeStyle() {
        return "-fx-background-color: #b0b0b0;" +
                "-fx-text-fill: white;" +
                "-fx-padding: 8;" +
                "-fx-border-color: #777777;" +
                "-fx-border-width: 1;";
    }

    /**
     * Lógica: devolve o estilo ativo usado por emblemas cumpridos.
     * Requisitos: Req. 7.
     */
    private String createActiveBadgeStyle(String color) {
        return "-fx-background-color: " + color + ";" +
                "-fx-text-fill: white;" +
                "-fx-padding: 8;" +
                "-fx-border-color: black;" +
                "-fx-border-width: 1;";
    }

    /**
     * Lógica: escolhe o estilo ativo ou inativo conforme o estado do emblema.
     * Requisitos: Req. 7.
     */
    private void updateBadge(Label badge, boolean achieved, String activeColor) {
        if (achieved) {
            badge.setStyle(this.createActiveBadgeStyle(activeColor));
        } else {
            badge.setStyle(this.createInactiveBadgeStyle());
        }
    }

    /**
     * Lógica: atualiza visualmente os três emblemas com base nos booleanos enviados pelo modelo.
     * Requisitos: Req. 7, RPB 1.
     */
    @Override
    public void updateOdsBadges(boolean ods2Achieved, boolean ods3Achieved, boolean ods12Achieved) {
        this.updateBadge(this.ods2BadgeLabel, ods2Achieved, "#4C9F38");
        this.updateBadge(this.ods3BadgeLabel, ods3Achieved, "#4C9F38");
        this.updateBadge(this.ods12BadgeLabel, ods12Achieved, "#4C9F38");
    }


    /**
     * Lógica: cria botões de filtro, ComboBox de ordenação e botões de undo/redo.
     * Requisitos: Req. 8, Req. 10.
     */
    private HBox createFilterBar() {
        Button showAllButton = new Button(FILTER_ALL);
        Button greenButton = new Button(FILTER_GREEN);
        Button proteinsButton = new Button(FILTER_PROTEINS);

        showAllButton.setOnAction(event -> this.changeFilter(FILTER_ALL));
        greenButton.setOnAction(event -> this.changeFilter(FILTER_GREEN));
        proteinsButton.setOnAction(event -> this.changeFilter(FILTER_PROTEINS));

        ComboBox<String> orderComboBox = new ComboBox<>();

        orderComboBox.getItems().add(ORDER_NONE);
        orderComboBox.getItems().add(ORDER_PRICE_ASC);
        orderComboBox.getItems().add(ORDER_CALORIES_DESC);

        orderComboBox.setValue(ORDER_NONE);

        orderComboBox.setOnAction(event -> {
            this.currentOrder = orderComboBox.getValue();
            this.refreshFoodGrid();
        });

        Button removeButton = new Button("Remover artigo");
        removeButton.setOnAction(event -> this.removeLastItem());

        Button restoreButton = new Button("Voltar atrás");
        restoreButton.setOnAction(event -> this.restoreLastRemovedItem());

        HBox filterBar = new HBox(
                showAllButton,
                greenButton,
                proteinsButton,
                orderComboBox,
                removeButton,
                restoreButton
        );

        filterBar.setSpacing(10);
        filterBar.setStyle("-fx-padding: 20 20 0 20;");

        return filterBar;
    }

    /**
     * Lógica: guarda o filtro escolhido e reconstrói a grelha.
     * Requisitos: Req. 8.
     */
    private void changeFilter(String filter) {
        this.currentFilter = filter;
        this.refreshFoodGrid();
    }

    /**
     * Lógica: limpa a grelha, aplica filtro/ordenação e volta a desenhar os tiles visíveis.
     * Requisitos: Req. 4, Req. 8.
     */
    private void refreshFoodGrid() {
        this.foodGrid.getChildren().clear();

        ArrayList<FoodItem> visibleFoods = this.getFilteredFoods();
        this.sortVisibleFoods(visibleFoods);

        int columns = 4;

        for (int i = 0; i < visibleFoods.size(); i++) {
            FoodItem food = visibleFoods.get(i);

            VBox tile = this.createFoodTile(food);

            int row = i / columns;
            int column = i % columns;

            this.foodGrid.add(tile, column, row);
        }
    }

    /**
     * Lógica: cria a lista de alimentos visíveis de acordo com o filtro atual.
     * Requisitos: Req. 8.
     */
    private ArrayList<FoodItem> getFilteredFoods() {
        ArrayList<FoodItem> visibleFoods = new ArrayList<>();

        for (FoodItem food : this.model.getAvailableFoods()) {
            if (this.shouldShowFood(food)) {
                visibleFoods.add(food);
            }
        }

        return visibleFoods;
    }

    /**
     * Lógica: decide se um alimento aparece na grelha conforme o filtro ativo.
     * Requisitos: Req. 8.
     */
    private boolean shouldShowFood(FoodItem food) {
        boolean shouldShow = false;

        if (this.currentFilter.equals(FILTER_ALL)) {
            shouldShow = true;
        } else if (this.currentFilter.equals(FILTER_GREEN)) {
            shouldShow = food.getGroup() == FoodGroup.GREEN;
        } else if (this.currentFilter.equals(FILTER_PROTEINS)) {
            shouldShow = food.getGroup() == FoodGroup.RED;
        }

        return shouldShow;
    }

    /**
     * Lógica: ordena os alimentos visíveis por preço ou calorias conforme a ComboBox.
     * Requisitos: Req. 8.
     */
    private void sortVisibleFoods(ArrayList<FoodItem> visibleFoods) {
        if (this.currentOrder.equals(ORDER_PRICE_ASC)) {
            visibleFoods.sort(Comparator.comparingDouble(FoodItem::getBasePrice));
        } else if (this.currentOrder.equals(ORDER_CALORIES_DESC)) {
            visibleFoods.sort(
                    Comparator.comparingDouble(FoodItem::getBaseCalories).reversed()
            );
        }
    }

    /**
     * Lógica: pede ao modelo para remover o último item e mostra erro se não houver item.
     * Requisitos: Req. 10.
     */
    private void removeLastItem() {
        boolean removed = this.model.removeLastItem();

        if (!removed) {
            this.showError("Não existe nenhum artigo para remover.");
        }
    }

    /**
     * Lógica: pede ao modelo para repor o último item removido e mostra erro se não houver item.
     * Requisitos: Req. 10.
     */
    private void restoreLastRemovedItem() {
        boolean restored = this.model.restoreLastRemovedItem();

        if (!restored) {
            this.showError("Não existe nenhum artigo para voltar atrás.");
        }
    }

    /**
     * Lógica: arranca a aplicação JavaFX principal.
     * Requisitos: Req. 4.
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Lógica: cria o menu Ficheiro com a opção Importar Recibo.
     * Requisitos: Req. 12.
     */
    private MenuBar createMenuBar(Stage stage) {
        Menu fileMenu = new Menu("Ficheiro");

        MenuItem importReceiptItem = new MenuItem("Importar Recibo");
        importReceiptItem.setOnAction(event -> this.importReceipt(stage));

        fileMenu.getItems().add(importReceiptItem);

        return new MenuBar(fileMenu);
    }

    /**
     * Lógica: abre a escolha de ficheiro e importa o recibo se o utilizador selecionar um ficheiro.
     * Requisitos: Req. 12.
     */
    private void importReceipt(Stage stage) {
        File selectedFile = this.chooseReceiptFile(stage);

        if (selectedFile != null) {
            this.importSelectedReceipt(selectedFile);
        }
    }

    /**
     * Lógica: abre um FileChooser limitado a ficheiros de texto.
     * Requisitos: Req. 12.
     */
    private File chooseReceiptFile(Stage stage) {
        FileChooser fileChooser = new FileChooser();

        fileChooser.setTitle("Importar Recibo");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Ficheiros de texto", "*.txt")
        );

        return fileChooser.showOpenDialog(stage);
    }

    /**
     * Lógica: pede ao modelo para ler o recibo e inicia o replay visual.
     * Requisitos: Req. 12.
     */
    private void importSelectedReceipt(File selectedFile) {
        try {
            List<FoodItem> receiptItems = this.model.importReceiptItems(selectedFile.getPath());
            this.replayReceiptItems(receiptItems);
        } catch (IOException exception) {
            this.showError("Não foi possível importar o recibo.");
        }
    }


    /**
     * Lógica: valida se o recibo tinha itens válidos antes de começar o replay.
     * Requisitos: Req. 12.
     */
    private void replayReceiptItems(List<FoodItem> receiptItems) {
        if (receiptItems.isEmpty()) {
            this.showError("O recibo não contém artigos válidos.");
        } else {
            this.startReceiptReplay(receiptItems);
        }
    }

    /**
     * Lógica: limpa o cabaz e agenda a entrada dos itens com atraso de meio segundo.
     * Requisitos: Req. 12.
     */
    private void startReceiptReplay(List<FoodItem> receiptItems) {
        this.model.clear();

        Timeline timeline = new Timeline();

        for (int i = 0; i < receiptItems.size(); i++) {
            FoodItem item = receiptItems.get(i);
            KeyFrame keyFrame = this.createReplayKeyFrame(item, i);

            timeline.getKeyFrames().add(keyFrame);
        }

        timeline.play();
    }

    /**
     * Lógica: cria um passo da Timeline para adicionar um item ao cabaz no momento correto.
     * Requisitos: Req. 12.
     */
    private KeyFrame createReplayKeyFrame(FoodItem item, int index) {
        return new KeyFrame(
                Duration.millis(500.0 * (index + 1)),
                event -> this.model.addItem(item)
        );
    }

}