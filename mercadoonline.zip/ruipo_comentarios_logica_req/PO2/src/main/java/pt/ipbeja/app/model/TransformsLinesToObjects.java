/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lógica: transforma linhas do ficheiro CSV em objetos FoodItem, ignorando linhas inválidas.
 * Requisitos: Req. 3, Req. 4, RPB 2.
 */
public class TransformsLinesToObjects {

    private static final int Type_Index = 0;
    private static final int Name_Index = 1;
    private static final int Group_Index = 2;
    private static final int BasePrice_Index = 3;
    private static final int BaseCalories_Index = 4;
    private static final int InfoExtra_Index = 5;

    private static final int N_Atributes_Expected = 6;

    private static final String Type_Packaged = "EMBALADO";
    private static final String Type_Bulk = "POR PESO";

    /**
     * Lógica: lê o CSV linha a linha, cria alimentos válidos e acumula texto das linhas inválidas.
     * Requisitos: Req. 3, Req. 4.
     */
    public LoadedFoods FoodsFromCSV(String filepath) {
        List<FoodItem> foods = new ArrayList<>();
        StringBuilder ignoredLines = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new FileReader(filepath))) {
            String line = reader.readLine();

            while (line != null) {
                if (!this.isHeaderLine(line) && !line.trim().isEmpty()) {
                    try {
                        FoodItem food = this.createFoodFromLine(line);
                        foods.add(food);
                    } catch (IllegalArgumentException exception) {
                        ignoredLines.append(line).append(System.lineSeparator());
                    }
                }

                line = reader.readLine();
            }

        } catch (IOException exception) {
            ignoredLines.append("Could not read file: ").append(filepath).append(System.lineSeparator());
        }

        return new LoadedFoods(foods, ignoredLines.toString());
    }

    /**
     * Lógica: identifica o cabeçalho do CSV para não tentar transformá-lo em alimento.
     * Requisitos: Req. 3.
     */
    private boolean isHeaderLine(String line) {
        return line.trim().toLowerCase().startsWith("tipo;nome;grupo");
    }

    /**
     * Lógica: divide uma linha CSV, valida o número de campos e cria PackagedFood ou BulkFood conforme o campo Tipo.
     * Requisitos: Req. 3, Req. 4, RPB 2.
     */
    private FoodItem createFoodFromLine(String line) {
        String[] fields = line.split(";");

        if (fields.length != N_Atributes_Expected) {
            throw new IllegalArgumentException("Invalid number of fields.");
        }

        String type = fields[Type_Index].trim().toUpperCase();
        String name = fields[Name_Index].trim();
        FoodGroup group = FoodGroup.valueOf(fields[Group_Index].trim().toUpperCase());
        double basePrice = Double.parseDouble(fields[BasePrice_Index].trim());
        double baseCalories = Double.parseDouble(fields[BaseCalories_Index].trim());
        String extraInfo = fields[InfoExtra_Index].trim();

        if (type.equals(Type_Packaged)) {
            return new PackagedFood(name, group, basePrice, baseCalories, extraInfo);
        }

        if (type.equals(Type_Bulk)) {
            double selectedWeight = Double.parseDouble(extraInfo);
            return new BulkFood(name, group, basePrice, baseCalories, selectedWeight);
        }

        throw new IllegalArgumentException("Invalid food type.");
    }
}


