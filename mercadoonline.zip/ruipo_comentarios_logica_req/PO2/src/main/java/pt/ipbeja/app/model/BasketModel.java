/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Lógica: representa o modelo do cabaz, guardando o estado da aplicação e concentrando os cálculos/regras de negócio.
 * Requisitos: Req. 1, Req. 2, Req. 3, Req. 4, Req. 5, Req. 7, Req. 10, Req. 12, RPB 1, RPB 2.
 */
public class BasketModel {


    private static final double Healthy_Green = 400.0;
    private static final int ODS2_MINIMUM_GROUPS = 4;
    private static final double ODS12_MINIMUM_BULK_PERCENTAGE = 0.5;
    private final List<FoodItem> items;
    private final List<FoodItem> availableFoods;
    private final List<FoodItem> removedItems;


    private View view;

    /**
     * Lógica: inicializa as listas internas do cabaz, dos alimentos disponíveis e do histórico de undo/redo.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 7, Req. 10, Req. 12.
     */
    public BasketModel() {
        this.items = new ArrayList<>();
        this.availableFoods = new ArrayList<>();
        this.removedItems = new ArrayList<>();
    }

    /**
     * Lógica: adiciona um item ao cabaz, limpa o histórico de redo e notifica a View para atualizar totais e emblemas.
     * Requisitos: Req. 1, Req. 4, Req. 7, Req. 10, Req. 12.
     */
    public void addItem(FoodItem item) {
        this.items.add(item);
        this.removedItems.clear();
        this.notifyView();
    }

    /**
     * Lógica: devolve uma cópia defensiva da lista interna para proteger o encapsulamento do cabaz.
     * Requisitos: Req. 1, Req. 5, Req. 12.
     */
    public List<FoodItem> getItems() {
        return new ArrayList<>(this.items);
    }

    /**
     * Lógica: soma os preços dos itens chamando FoodItem.getPrice(), usando polimorfismo.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5.
     */
    public double getTotalPrice() {
        double total = 0.0;

        for (FoodItem item : this.items) {
            total += item.getPrice();
        }

        return total;
    }

    /**
     * Lógica: soma as calorias dos itens chamando FoodItem.getCalories(), usando polimorfismo.
     * Requisitos: Req. 1, Req. 2, Req. 4.
     */
    public double getTotalCalories() {
        double total = 0.0;

        for (FoodItem item : this.items) {
            total += item.getCalories();
        }

        return total;
    }

    /**
     * Lógica: soma o peso verde fornecido pelos itens e verifica se atinge pelo menos 400g.
     * Requisitos: Req. 2, Req. 5, Req. 7.
     */
    public boolean isOds3Achieved() {
        double totalGreenWeight = 0.0;

        for (FoodItem item : this.items) {
            totalGreenWeight += item.getGreenWeight();
        }

        return totalGreenWeight >= Healthy_Green;
    }

    /**
     * Lógica: remove todos os itens do cabaz e notifica a View para reconstruir o estado visual.
     * Requisitos: Req. 12.
     */
    public void clear() {
        this.items.clear();
        this.notifyView();
    }



    /**
     * Lógica: carrega os alimentos disponíveis a partir do CSV e guarda-os no modelo.
     * Requisitos: Req. 3, Req. 4.
     */
    public LoadedFoods loadAvailableFoods(String filePath) {
        TransformsLinesToObjects factory = new TransformsLinesToObjects();
        LoadedFoods result = factory.FoodsFromCSV(filePath);

        this.availableFoods.clear();
        this.availableFoods.addAll(result.getFoods());

        return result;
    }

    /**
     * Lógica: devolve uma cópia dos alimentos disponíveis para a UI desenhar, filtrar e ordenar tiles.
     * Requisitos: Req. 4, Req. 8, Req. 12.
     */
    public List<FoodItem> getAvailableFoods() {
        return new ArrayList<>(this.availableFoods);
    }


    /**
     * Lógica: guarda a referência da View para o modelo conseguir comunicar alterações sem depender da UI concreta.
     * Requisitos: Req. 4, Req. 7, RPB 1.
     */
    public void setView(View view) {
        this.view = view;
    }

    /**
     * Lógica: encaminha a seleção para o próprio FoodItem, evitando instanceof na interface.
     * Requisitos: Req. 4, RPB 2.
     */
    public void selectFood(FoodItem food) {
        food.addToBasket(this, this.view);
    }

    /**
     * Lógica: avisa a View sempre que o modelo muda e envia o estado atual dos emblemas ODS.
     * Requisitos: Req. 4, Req. 7, Req. 10, Req. 12, RPB 1.
     */
    private void notifyView() {
        if (this.view != null) {
            this.view.update();
            this.view.updateOdsBadges(
                    this.isOds2Achieved(),
                    this.isOds3Achieved(),
                    this.isOds12Achieved()
            );
        }
    }

    /**
     * Lógica: delega a escrita do recibo para a classe Receipt, usando os itens e totais atuais.
     * Requisitos: Req. 5.
     */
    public String exportReceipt() throws IOException {
        Receipt exporter = new Receipt();

        return exporter.exportReceipt(
                this.getItems(),
                this.getTotalPrice(),
                this.isOds3Achieved()
        );
    }

    /**
     * Lógica: conta os grupos alimentares distintos no cabaz e verifica se existem pelo menos quatro.
     * Requisitos: Req. 7.
     */
    public boolean isOds2Achieved() {
        List<FoodGroup> groups = new ArrayList<>();

        for (FoodItem item : this.items) {
            if (!groups.contains(item.getGroup())) {
                groups.add(item.getGroup());
            }
        }

        return groups.size() >= ODS2_MINIMUM_GROUPS;
    }

    /**
     * Lógica: calcula se mais de metade dos itens do cabaz são alimentos a granel.
     * Requisitos: Req. 7.
     */
    private boolean hasMoreThanHalfBulkItems() {
        int bulkItems = 0;

        for (FoodItem item : this.items) {
            if (item.countsAsBulkForOds12()) {
                bulkItems++;
            }
        }

        return ((double) bulkItems / this.items.size()) > ODS12_MINIMUM_BULK_PERCENTAGE;
    }

    /**
     * Lógica: verifica se algum item do cabaz declara embalagem de plástico.
     * Requisitos: Req. 7.
     */
    private boolean hasPlasticPackaging() {
        boolean hasPlastic = false;

        for (FoodItem item : this.items) {
            if (item.hasPlasticPackaging()) {
                hasPlastic = true;
            }
        }

        return hasPlastic;
    }

    /**
     * Lógica: confirma ODS 12 combinando percentagem de granel e ausência de embalagens de plástico.
     * Requisitos: Req. 7.
     */
    public boolean isOds12Achieved() {
        return !this.items.isEmpty() &&
                this.hasMoreThanHalfBulkItems() &&
                !this.hasPlasticPackaging();
    }

    /**
     * Lógica: remove o último item inserido e guarda-o para permitir voltar atrás.
     * Requisitos: Req. 10.
     */
    public boolean removeLastItem() {
        if (this.items.isEmpty()) {
            return false;
        }

        FoodItem removedItem = this.items.remove(this.items.size() - 1);
        this.removedItems.add(removedItem);
        this.notifyView();

        return true;
    }

    /**
     * Lógica: repõe no cabaz o último item removido pelo undo.
     * Requisitos: Req. 10.
     */
    public boolean restoreLastRemovedItem() {
        if (this.removedItems.isEmpty()) {
            return false;
        }

        FoodItem restoredItem = this.removedItems.remove(this.removedItems.size() - 1);
        this.items.add(restoredItem);
        this.notifyView();

        return true;
    }

    /**
     * Lógica: delega a leitura de recibos para ReceiptImporter e devolve os itens reconstruídos.
     * Requisitos: Req. 12.
     */
    public List<FoodItem> importReceiptItems(String filePath) throws IOException {
        ReceiptImporter importer = new ReceiptImporter();

        return importer.importReceiptItems(filePath, this.getAvailableFoods());
    }
}

