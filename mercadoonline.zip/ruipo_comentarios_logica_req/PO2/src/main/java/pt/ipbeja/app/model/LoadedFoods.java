/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Lógica: guarda o resultado da leitura do CSV, incluindo alimentos válidos e linhas ignoradas.
 * Requisitos: Req. 3, Req. 4.
 */
public class LoadedFoods {

    private final List<FoodItem> foods;
    private final String ignoredLinesText;

    /**
     * Lógica: guarda uma cópia dos alimentos lidos e o texto das linhas ignoradas.
     * Requisitos: Req. 3, Req. 4.
     */
    public LoadedFoods(List<FoodItem> foods, String ignoredLinesText) {
        this.foods = new ArrayList<>(foods);
        this.ignoredLinesText = ignoredLinesText;
    }

    /**
     * Lógica: devolve uma cópia dos alimentos carregados para proteger o encapsulamento.
     * Requisitos: Req. 3, Req. 4.
     */
    public List<FoodItem> getFoods() {
        return new ArrayList<>(this.foods);
    }

    /**
     * Lógica: devolve o texto acumulado das linhas do CSV que não foram aceites.
     * Requisitos: Req. 3, Req. 4.
     */
    public String getIgnoredLinesText() {
        return this.ignoredLinesText;
    }

    /**
     * Lógica: indica se existem linhas ignoradas para a View poder mostrar aviso.
     * Requisitos: Req. 3, Req. 4.
     */
    public boolean hasIgnoredLines() {
        return !this.ignoredLinesText.isEmpty();
    }
}
