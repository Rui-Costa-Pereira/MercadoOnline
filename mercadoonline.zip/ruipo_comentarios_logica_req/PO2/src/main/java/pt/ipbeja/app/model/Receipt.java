/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Lógica: exporta o recibo da compra para ficheiro de texto.
 * Requisitos: Req. 5.
 */
public class Receipt {

    private static final String RECEIPT_PREFIX = "receipt_";
    private static final String RECEIPT_EXTENSION = ".txt";
    private static final String DATE_PATTERN = "yyyyMMdd";

    /**
     * Lógica: cria o ficheiro de recibo e escreve cabeçalho, itens, total e mensagem ODS 3.
     * Requisitos: Req. 5.
     */
    public String exportReceipt(List<FoodItem> items, double totalPrice, boolean ods3Achieved) throws IOException {
        String fileName = this.createFileName();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            this.writeHeader(writer);
            this.writeItems(writer, items);
            this.writeTotal(writer, totalPrice);
            this.writeOds3Message(writer, ods3Achieved);
        }

        return fileName;
    }

    /**
     * Lógica: cria o nome do ficheiro com o prefixo receipt_ e a data atual.
     * Requisitos: Req. 5.
     */
    private String createFileName() {
        String dateText = LocalDate.now().format(DateTimeFormatter.ofPattern(DATE_PATTERN));
        return RECEIPT_PREFIX + dateText + RECEIPT_EXTENSION;
    }

    /**
     * Lógica: escreve o título inicial do recibo.
     * Requisitos: Req. 5.
     */
    private void writeHeader(BufferedWriter writer) throws IOException {
        writer.write("Recibo da Compra");
        writer.newLine();
        writer.write("----------------");
        writer.newLine();
    }

    /**
     * Lógica: escreve uma linha de recibo por cada item comprado.
     * Requisitos: Req. 5.
     */
    private void writeItems(BufferedWriter writer, List<FoodItem> items) throws IOException {
        for (FoodItem item : items) {
            writer.write(item.getReceiptLine());
            writer.newLine();
        }
    }

    /**
     * Lógica: escreve o grande total da compra.
     * Requisitos: Req. 5.
     */
    private void writeTotal(BufferedWriter writer, double totalPrice) throws IOException {
        writer.newLine();
        writer.write(String.format("Grande Total: %.2f €", totalPrice));
        writer.newLine();
    }

    /**
     * Lógica: escreve se a meta ODS 3 foi cumprida ou falhada.
     * Requisitos: Req. 5.
     */
    private void writeOds3Message(BufferedWriter writer, boolean ods3Achieved) throws IOException {
        if (ods3Achieved) {
            writer.write("Meta ODS 3 Cumprida!");
        } else {
            writer.write("Meta ODS 3 Falhada!");
        }

        writer.newLine();
    }
}

