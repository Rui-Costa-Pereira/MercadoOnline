/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.util.Optional;
/**
 * Lógica: define os atributos e comportamentos comuns a todos os alimentos, servindo de base polimórfica.
 * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, Req. 6, Req. 7, Req. 12, RPB 2.
 */
public abstract class FoodItem {


    private final String name;
    private final FoodGroup group;
    private final double basePrice;
    private final double baseCalories;

    /**
     * Lógica: guarda os atributos comuns a todos os alimentos.
     * Requisitos: Req. 1, Req. 4, Req. 5, Req. 6, Req. 7, Req. 12, RPB 2.
     */
    public FoodItem(String name, FoodGroup group, double basePrice, double baseCalories) {
        this.name = name;
        this.group = group;
        this.basePrice = basePrice;
        this.baseCalories = baseCalories;
    }

    /**
     * Lógica: devolve o nome do alimento.
     * Requisitos: Req. 1, Req. 4, Req. 5, Req. 12.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Lógica: devolve o grupo alimentar do alimento.
     * Requisitos: Req. 1, Req. 4, Req. 7, Req. 8.
     */
    public FoodGroup getGroup() {
        return this.group;
    }

    /**
     * Lógica: devolve o preço base usado nos cálculos e na apresentação dos tiles.
     * Requisitos: Req. 1, Req. 4, Req. 8.
     */
    public double getBasePrice() {
        return this.basePrice;
    }

    /**
     * Lógica: devolve as calorias base usadas nos cálculos e na ordenação.
     * Requisitos: Req. 1, Req. 4, Req. 8.
     */
    public double getBaseCalories() {

        return this.baseCalories;
    }

    /**
     * Lógica: define por defeito que um alimento não contribui peso verde; subclasses podem alterar este comportamento.
     * Requisitos: Req. 2, Req. 7, RPB 2.
     */
    public double getGreenWeight() {
        return 0.0;
    }

    /**
     * Lógica: obriga cada subclasse a calcular o preço final à sua maneira.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, RPB 2.
     */
    public abstract double getPrice();

    /**
     * Lógica: obriga cada subclasse a calcular as calorias finais à sua maneira.
     * Requisitos: Req. 1, Req. 2, Req. 4, RPB 2.
     */
    public abstract double getCalories();

    /**
     * Lógica: obriga cada subclasse a definir como o alimento é adicionado ao cabaz.
     * Requisitos: Req. 4, RPB 2.
     */
    public abstract void addToBasket(BasketModel model, View view);

    /**
     * Lógica: obriga cada subclasse a fornecer o texto visual do tipo de venda.
     * Requisitos: Req. 6, RPB 2.
     */
    public abstract String getSaleTypeText();

    /**
     * Lógica: obriga cada subclasse a fornecer a quantidade usada no recibo.
     * Requisitos: Req. 5, RPB 2.
     */
    public abstract String getReceiptQuantityText();

    /**
     * Lógica: monta uma linha do recibo usando nome, quantidade polimórfica e preço final.
     * Requisitos: Req. 5, RPB 2.
     */
    public String getReceiptLine() {
        return this.getName() + " | " +
                this.getReceiptQuantityText() + " | " +
                String.format("%.2f €", this.getPrice());
    }


    /**
     * Lógica: define por defeito que o item não conta como granel para ODS 12.
     * Requisitos: Req. 7, RPB 2.
     */
    public boolean countsAsBulkForOds12() {
        return false;
    }

    /**
     * Lógica: define por defeito que o item não tem embalagem de plástico.
     * Requisitos: Req. 7, RPB 2.
     */
    public boolean hasPlasticPackaging() {
        return false;
    }

    /**
     * Lógica: obriga cada subclasse a reconstruir um item a partir da quantidade lida no recibo.
     * Requisitos: Req. 12, RPB 2.
     */
    public abstract Optional<FoodItem> createFromReceiptQuantity(String quantityText);


}
