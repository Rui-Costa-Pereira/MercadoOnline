/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

import java.util.Optional;

/**
 * Lógica: representa alimentos vendidos a granel, cujo preço e calorias dependem do peso escolhido.
 * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, Req. 6, Req. 7, Req. 12, RPB 2.
 */
public class BulkFood extends FoodItem {

    private final double selectedWeight;
    private static final double grams_per_kilo = 1000.0;

    /**
     * Lógica: cria um alimento a granel com os dados comuns e o peso selecionado em gramas.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, Req. 6, Req. 7, Req. 12.
     */
    public BulkFood(String name, FoodGroup group, double basePrice,
                    double baseCalories, double selectedWeight)
    {
        super(name, group, basePrice, baseCalories);
        this.selectedWeight = selectedWeight;
    }

    /**
     * Lógica: devolve o peso escolhido para este item a granel.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5, Req. 7, Req. 12.
     */
    public double getSelectedWeight() {
        return this.selectedWeight;
    }

    /**
     * Lógica: calcula o preço proporcional ao peso escolhido, assumindo preço base por quilograma.
     * Requisitos: Req. 1, Req. 2, Req. 4, Req. 5.
     */
    @Override
    public double getPrice() {
        return this.getBasePrice() * this.selectedWeight / grams_per_kilo;
    }

    /**
     * Lógica: calcula as calorias proporcionais ao peso escolhido.
     * Requisitos: Req. 1, Req. 2, Req. 4.
     */
    @Override
    public double getCalories() {
        return this.getBaseCalories() * this.selectedWeight / grams_per_kilo;
    }

    /**
     * Lógica: devolve o peso apenas quando o alimento pertence ao grupo GREEN; caso contrário devolve zero.
     * Requisitos: Req. 2, Req. 7.
     */
    @Override
    public double getGreenWeight() {
        if (this.getGroup() == FoodGroup.GREEN) {
            return this.getSelectedWeight();
        }

        return 0.0;
    }

    /**
     * Lógica: pede à View o peso pretendido e, se válido, adiciona ao cabaz uma nova instância com esse peso.
     * Requisitos: Req. 4, RPB 2.
     */
    @Override
    public void addToBasket(BasketModel model, View view) {
        Optional<Double> selectedWeight = view.askSelectedWeight(this.getName());

        if (selectedWeight.isPresent()) {
            this.addSelectedWeightToBasket(model, view, selectedWeight.get());
        }
    }

    /**
     * Lógica: devolve o texto usado no tile para identificar venda a granel.
     * Requisitos: Req. 6.
     */
    @Override
    public String getSaleTypeText() {
        return "A granel - €/kg";
    }

    /**
     * Lógica: valida se o peso é superior a zero e adiciona o alimento ao modelo; caso contrário mostra erro.
     * Requisitos: Req. 4.
     */
    private void addSelectedWeightToBasket(BasketModel model, View view, double selectedWeight) {
        if (selectedWeight > 0) {
            BulkFood selectedFood = new BulkFood(
                    this.getName(),
                    this.getGroup(),
                    this.getBasePrice(),
                    this.getBaseCalories(),
                    selectedWeight
            );

            model.addItem(selectedFood);
        } else {
            view.showError("O peso deve ser superior a zero.");
        }
    }
    /**
     * Lógica: formata o peso em gramas para a linha do recibo.
     * Requisitos: Req. 5.
     */
    @Override
    public String getReceiptQuantityText() {
        return String.format("%.0f g", this.selectedWeight);
    }


    /**
     * Lógica: indica que este item conta como alimento a granel para o ODS 12.
     * Requisitos: Req. 7.
     */
    @Override
    public boolean countsAsBulkForOds12() {
        return true;
    }


    /**
     * Lógica: reconstrói um alimento a granel a partir do peso guardado no recibo.
     * Requisitos: Req. 12.
     */
    @Override
    public Optional<FoodItem> createFromReceiptQuantity(String quantityText) {
        Optional<FoodItem> foodItem = Optional.empty();

        try {
            double selectedWeight = this.parseReceiptWeight(quantityText);

            if (selectedWeight > 0) {
                foodItem = Optional.of(this.createSelectedWeightFood(selectedWeight));
            }
        } catch (NumberFormatException exception) {
            foodItem = Optional.empty();
        }

        return foodItem;
    }

    /**
     * Lógica: remove o sufixo g do texto do recibo e converte o valor para número.
     * Requisitos: Req. 12.
     */
    private double parseReceiptWeight(String quantityText) {
        String weightText = quantityText.toLowerCase()
                .replace("g", "")
                .trim();

        return Double.parseDouble(weightText);
    }

    /**
     * Lógica: cria uma nova instância BulkFood com o mesmo alimento base e o peso importado.
     * Requisitos: Req. 12.
     */
    private BulkFood createSelectedWeightFood(double selectedWeight) {
        return new BulkFood(
                this.getName(),
                this.getGroup(),
                this.getBasePrice(),
                this.getBaseCalories(),
                selectedWeight
        );
    }

}
