/*
 * Autor: Rui Costa Pereira
 * Número de aluno: 24478
 * Apoio de IA generativa: houve apoio de IA no desenvolvimento desta classe.
 */

package pt.ipbeja.app.model;

/**
 * Lógica: representa os grupos da roda dos alimentos e associa a cada grupo uma descrição e uma cor.
 * Requisitos: Req. 1, Req. 4, Req. 7, Req. 8.
 */
public enum FoodGroup {


    GREEN("Hortícolas/Frutas", "green"),
    YELLOW("Cereais", "yellow"),
    BLUE("Laticínios", "blue"),
    BROWN("Leguminosas", "brown"),
    RED("Carnes/Peixe", "red"),
    ORANGE("Gorduras", "orange");

    private final String description;
    private final String colorName;

    FoodGroup(String description, String colorName) {
        this.description = description;
        this.colorName = colorName;
    }

    /**
     * Lógica: devolve a descrição textual do grupo alimentar.
     * Requisitos: Req. 1, Req. 4, Req. 7, Req. 8.
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Lógica: devolve a cor associada ao grupo alimentar para usar nos tiles.
     * Requisitos: Req. 1, Req. 4.
     */
    public String getColorName() {
        return this.colorName;
    }
}
